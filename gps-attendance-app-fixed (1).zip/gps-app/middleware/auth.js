const { verifyToken } = require('../utils');

function requireAuth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    const payload = verifyToken(token);
    if (!payload) return res.status(401).json({ error: 'Invalid or expired token' });
    if (role && payload.role !== role) return res.status(403).json({ error: 'Forbidden' });
    req.user = payload;
    next();
  };
}

// Gates routes to admins whose adminRole is 'superadmin'. Must run after
// requireAuth('admin') so req.user is already populated. 'manager'-role
// admins get a 403 with a clear message instead of the generic Forbidden.
function requireSuperAdmin(req, res, next) {
  if (req.user?.adminRole !== 'superadmin') {
    return res.status(403).json({ error: 'This action requires a Super Admin role.' });
  }
  next();
}

module.exports = { requireAuth, requireSuperAdmin };
