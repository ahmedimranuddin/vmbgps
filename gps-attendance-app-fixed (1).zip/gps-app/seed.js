// Bootstraps the data file with a first admin account and one demo office.
// Run once: node seed.js
const bcrypt = require('bcryptjs');
const { load, save, nextId } = require('./db/store');

const data = load();

if (data.admins.length === 0) {
  const admin = {
    id: nextId(data, 'admins'),
    username: 'admin',
    email: 'admin@example.com',
    passwordHash: bcrypt.hashSync('Admin@123', 10),
    role: 'superadmin',
    active: true
  };
  data.admins.push(admin);
  console.log('Created admin login -> username: admin / password: Admin@123 (change this immediately)');
} else {
  console.log('Admin already exists, skipping.');
}

if (data.offices.length === 0) {
  const office = {
    id: nextId(data, 'offices'),
    name: 'Main Office (Dhaka)',
    latitude: 23.780636,
    longitude: 90.279541,
    radiusMeters: 150,
    startTime: '09:00',
    graceMinutes: 15
  };
  data.offices.push(office);
  console.log(`Created demo office "${office.name}" — edit its coordinates in the admin panel to match your real office.`);
}

save(data);
console.log('Seed complete. Start the server with: npm start');
