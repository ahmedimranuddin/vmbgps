const express = require('express');
const bcrypt = require('bcryptjs');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { load, save, nextId, logAudit } = require('../db/store');
const { signToken, computeStatus, formatDuration, totalMinutesWorked, todayDateStr } = require('../utils');
const { requireAuth, requireSuperAdmin } = require('../middleware/auth');

const router = express.Router();

// ---------- Admin auth ----------
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });
  const data = load();
  const admin = data.admins.find(
    (a) => a.username.toLowerCase() === String(username).toLowerCase() || a.email?.toLowerCase() === String(username).toLowerCase()
  );
  if (!admin) return res.status(401).json({ error: 'Invalid credentials' });
  if (admin.active === false) return res.status(403).json({ error: 'This admin account has been deactivated.' });
  if (!bcrypt.compareSync(password, admin.passwordHash)) return res.status(401).json({ error: 'Invalid credentials' });
  const token = signToken({ role: 'admin', id: admin.id, username: admin.username, adminRole: admin.role || 'superadmin' });
  logAudit(data, { id: admin.id, username: admin.username }, 'Login', '');
  save(data);
  res.json({ token, admin: { id: admin.id, username: admin.username, email: admin.email, role: admin.role || 'superadmin' } });
});

// All routes below require admin auth
router.use(requireAuth('admin'));

// ---------- Office management ----------
// Viewing offices is fine for any admin (managers need it for filters/dropdowns);
// creating, editing, or deleting a location is a superadmin-only action.
router.get('/offices', (req, res) => {
  const data = load();
  res.json(data.offices);
});

router.post('/offices', requireSuperAdmin, (req, res) => {
  const { name, latitude, longitude, radiusMeters, startTime, graceMinutes } = req.body;
  if (!name || latitude == null || longitude == null || !radiusMeters || !startTime) {
    return res.status(400).json({ error: 'name, latitude, longitude, radiusMeters, startTime are required' });
  }
  const data = load();
  const office = {
    id: nextId(data, 'offices'),
    name,
    latitude: Number(latitude),
    longitude: Number(longitude),
    radiusMeters: Number(radiusMeters),
    startTime, // "09:00"
    graceMinutes: Number(graceMinutes || 0)
  };
  data.offices.push(office);
  logAudit(data, req.user, 'Add Office', `${office.name} (radius ${office.radiusMeters}m, start ${office.startTime})`);
  save(data);
  res.json(office);
});

router.put('/offices/:id', requireSuperAdmin, (req, res) => {
  const data = load();
  const office = data.offices.find((o) => o.id === Number(req.params.id));
  if (!office) return res.status(404).json({ error: 'Office not found' });
  const { name, latitude, longitude, radiusMeters, startTime, graceMinutes } = req.body;
  if (name != null) office.name = name;
  if (latitude != null) office.latitude = Number(latitude);
  if (longitude != null) office.longitude = Number(longitude);
  if (radiusMeters != null) office.radiusMeters = Number(radiusMeters);
  if (startTime != null) office.startTime = startTime;
  if (graceMinutes != null) office.graceMinutes = Number(graceMinutes);
  logAudit(data, req.user, 'Edit Office', office.name);
  save(data);
  res.json(office);
});

router.delete('/offices/:id', requireSuperAdmin, (req, res) => {
  const data = load();
  const idx = data.offices.findIndex((o) => o.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Office not found' });
  const removed = data.offices[idx];

  const assignedCount = data.employees.filter((e) => e.officeId === removed.id && e.active).length;
  if (assignedCount > 0) {
    return res.status(400).json({
      error: `${assignedCount} active employee${assignedCount === 1 ? ' is' : 's are'} still assigned to "${removed.name}" — reassign them to a different office first (Employees tab) before deleting this location.`
    });
  }

  data.offices.splice(idx, 1);
  logAudit(data, req.user, 'Delete Office', removed.name);
  save(data);
  res.json({ ok: true });
});

// ---------- Employee management ----------
// Viewing the roster is available to any admin; adding/editing/deactivating
// employees, resetting passwords, and bulk import are superadmin-only.
router.get('/employees', (req, res) => {
  const data = load();
  res.json(data.employees.map(safeEmployee));
});

router.post('/employees', requireSuperAdmin, (req, res) => {
  const { employeeCode, name, mobile, password, department, designation, joiningDate, officeId } = req.body;
  if (!employeeCode || !name || !mobile || !password || !officeId) {
    return res.status(400).json({ error: 'employeeCode, name, mobile, password, officeId are required' });
  }
  const data = load();
  if (data.employees.some((e) => e.employeeCode === employeeCode || e.mobile === mobile)) {
    return res.status(409).json({ error: 'Employee code or mobile already exists' });
  }
  const employee = {
    id: nextId(data, 'employees'),
    employeeCode,
    name,
    mobile,
    passwordHash: bcrypt.hashSync(password, 10),
    department: department || '',
    designation: designation || '',
    joiningDate: joiningDate || null,
    officeId: Number(officeId),
    active: true,
    activeDeviceId: null // basic single-device control (section 7)
  };
  data.employees.push(employee);
  logAudit(data, req.user, 'Add Employee', `${employee.name} (${employee.employeeCode})`);
  save(data);
  res.json(safeEmployee(employee));
});

// Bulk-create employees from a parsed CSV (client sends an array of row objects).
// Each row: employeeCode, name, mobile, password, department, designation,
// joiningDate, officeName (matched case-insensitively) or officeId.
// Invalid or duplicate rows are skipped and reported back individually so a
// single bad row doesn't block the whole import.
router.post('/employees/bulk', requireSuperAdmin, (req, res) => {
  const rows = Array.isArray(req.body.employees) ? req.body.employees : null;
  if (!rows || !rows.length) return res.status(400).json({ error: 'employees array is required' });

  const data = load();
  const created = [];
  const skipped = [];

  rows.forEach((row, idx) => {
    const rowNum = idx + 2; // +2 so it lines up with a spreadsheet row (1 = header)
    const employeeCode = (row.employeeCode || '').trim();
    const name = (row.name || '').trim();
    const mobile = (row.mobile || '').trim();
    const password = (row.password || '').trim();
    const department = (row.department || '').trim();
    const designation = (row.designation || '').trim();
    const joiningDate = (row.joiningDate || '').trim() || null;

    if (!employeeCode || !name || !mobile || !password) {
      skipped.push({ row: rowNum, employeeCode, reason: 'Missing required field (employeeCode, name, mobile, or password)' });
      return;
    }

    let officeId = row.officeId ? Number(row.officeId) : null;
    if (!officeId && row.officeName) {
      const match = data.offices.find((o) => o.name.toLowerCase() === String(row.officeName).trim().toLowerCase());
      if (match) officeId = match.id;
    }
    if (!officeId || !data.offices.some((o) => o.id === officeId)) {
      skipped.push({ row: rowNum, employeeCode, reason: 'Office not found (check officeName spelling)' });
      return;
    }

    if (data.employees.some((e) => e.employeeCode === employeeCode) || created.some((e) => e.employeeCode === employeeCode)) {
      skipped.push({ row: rowNum, employeeCode, reason: 'Employee code already exists' });
      return;
    }
    if (data.employees.some((e) => e.mobile === mobile) || created.some((e) => e.mobile === mobile)) {
      skipped.push({ row: rowNum, employeeCode, reason: 'Mobile number already exists' });
      return;
    }

    const employee = {
      id: nextId(data, 'employees'),
      employeeCode,
      name,
      mobile,
      passwordHash: bcrypt.hashSync(password, 10),
      department,
      designation,
      joiningDate,
      officeId,
      active: true,
      activeDeviceId: null
    };
    data.employees.push(employee);
    created.push(employee);
  });

  logAudit(data, req.user, 'Bulk Import Employees', `${created.length} created, ${skipped.length} skipped`);
  save(data);
  res.json({ createdCount: created.length, created: created.map(safeEmployee), skipped });
});

router.put('/employees/:id', requireSuperAdmin, (req, res) => {
  const data = load();
  const emp = data.employees.find((e) => e.id === Number(req.params.id));
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const { name, mobile, department, designation, joiningDate, officeId, active } = req.body;
  if (name != null) emp.name = name;
  if (mobile != null) emp.mobile = mobile;
  if (department != null) emp.department = department;
  if (designation != null) emp.designation = designation;
  if (joiningDate != null) emp.joiningDate = joiningDate;
  if (officeId != null) emp.officeId = Number(officeId);
  if (active != null) emp.active = Boolean(active);
  logAudit(data, req.user, 'Edit Employee', `${emp.name} (${emp.employeeCode})`);
  save(data);
  res.json(safeEmployee(emp));
});

router.delete('/employees/:id', requireSuperAdmin, (req, res) => {
  // "Deactivate" per spec rather than hard delete
  const data = load();
  const emp = data.employees.find((e) => e.id === Number(req.params.id));
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  emp.active = false;
  logAudit(data, req.user, 'Deactivate Employee', `${emp.name} (${emp.employeeCode})`);
  save(data);
  res.json({ ok: true });
});

// Permanently removes an employee record. Only allowed when the employee has
// no punch history at all — otherwise attendance/report rows referencing
// their employeeId would end up with a blank name/code forever. For anyone
// who has ever punched in, use Deactivate instead (keeps history intact).
router.delete('/employees/:id/permanent', requireSuperAdmin, (req, res) => {
  const data = load();
  const id = Number(req.params.id);
  const emp = data.employees.find((e) => e.id === id);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });

  const hasPunches = data.punches.some((p) => p.employeeId === id);
  if (hasPunches) {
    return res.status(400).json({
      error: 'This employee has attendance history and cannot be permanently deleted — use Deactivate instead to preserve their records.'
    });
  }

  data.employees = data.employees.filter((e) => e.id !== id);
  logAudit(data, req.user, 'Delete Employee', `${emp.name} (${emp.employeeCode})`);
  save(data);
  res.json({ ok: true });
});

router.post('/employees/:id/reset-password', requireSuperAdmin, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword) return res.status(400).json({ error: 'newPassword is required' });
  const data = load();
  const emp = data.employees.find((e) => e.id === Number(req.params.id));
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  emp.passwordHash = bcrypt.hashSync(newPassword, 10);
  emp.activeDeviceId = null; // force re-login on new device
  logAudit(data, req.user, 'Reset Employee Password', `${emp.name} (${emp.employeeCode})`);
  save(data);
  res.json({ ok: true });
});

router.post('/employees/:id/unlock-device', requireSuperAdmin, (req, res) => {
  // Clears the single-device lock so employee can log in from a new phone
  const data = load();
  const emp = data.employees.find((e) => e.id === Number(req.params.id));
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  emp.activeDeviceId = null;
  logAudit(data, req.user, 'Unlock Employee Device', `${emp.name} (${emp.employeeCode})`);
  save(data);
  res.json({ ok: true });
});

function safeEmployee(e) {
  const { passwordHash, ...rest } = e;
  return rest;
}

// ---------- Admin account management (superadmin only) ----------
function safeAdmin(a) {
  const { passwordHash, ...rest } = a;
  return rest;
}

router.get('/admins', requireSuperAdmin, (req, res) => {
  const data = load();
  res.json(data.admins.map(safeAdmin));
});

router.post('/admins', requireSuperAdmin, (req, res) => {
  const { username, email, password, role } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username and password are required' });
  if (role && !['superadmin', 'manager'].includes(role)) {
    return res.status(400).json({ error: "role must be 'superadmin' or 'manager'" });
  }
  const data = load();
  if (data.admins.some((a) => a.username.toLowerCase() === username.toLowerCase())) {
    return res.status(409).json({ error: 'Username already exists' });
  }
  const admin = {
    id: nextId(data, 'admins'),
    username,
    email: email || '',
    passwordHash: bcrypt.hashSync(password, 10),
    role: role || 'manager',
    active: true
  };
  data.admins.push(admin);
  logAudit(data, req.user, 'Add Admin', `${admin.username} (${admin.role})`);
  save(data);
  res.json(safeAdmin(admin));
});

router.put('/admins/:id', requireSuperAdmin, (req, res) => {
  const data = load();
  const admin = data.admins.find((a) => a.id === Number(req.params.id));
  if (!admin) return res.status(404).json({ error: 'Admin not found' });
  const { email, role, active } = req.body;
  if (role != null) {
    if (!['superadmin', 'manager'].includes(role)) {
      return res.status(400).json({ error: "role must be 'superadmin' or 'manager'" });
    }
    if (admin.id === req.user.id && role !== 'superadmin') {
      return res.status(400).json({ error: 'You cannot remove your own Super Admin role.' });
    }
    admin.role = role;
  }
  if (email != null) admin.email = email;
  if (active != null) {
    if (admin.id === req.user.id && active === false) {
      return res.status(400).json({ error: 'You cannot deactivate your own account.' });
    }
    const remainingSuperadmins = data.admins.filter((a) => a.role === 'superadmin' && a.active !== false && a.id !== admin.id).length;
    if (active === false && admin.role === 'superadmin' && remainingSuperadmins === 0) {
      return res.status(400).json({ error: 'At least one active Super Admin must remain.' });
    }
    admin.active = Boolean(active);
  }
  logAudit(data, req.user, 'Edit Admin', `${admin.username}`);
  save(data);
  res.json(safeAdmin(admin));
});

router.post('/admins/:id/reset-password', requireSuperAdmin, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword) return res.status(400).json({ error: 'newPassword is required' });
  const data = load();
  const admin = data.admins.find((a) => a.id === Number(req.params.id));
  if (!admin) return res.status(404).json({ error: 'Admin not found' });
  admin.passwordHash = bcrypt.hashSync(newPassword, 10);
  logAudit(data, req.user, 'Reset Admin Password', admin.username);
  save(data);
  res.json({ ok: true });
});

// ---------- Audit log ----------
// Read access is available to any logged-in admin (transparency for managers too);
// only superadmins can change roster/office/admin data in the first place.
router.get('/audit-log', (req, res) => {
  const { fromDate, toDate, action, adminId, limit } = req.query;
  const data = load();
  let rows = [...data.auditLog];
  if (fromDate) rows = rows.filter((r) => r.timestamp.slice(0, 10) >= fromDate);
  if (toDate) rows = rows.filter((r) => r.timestamp.slice(0, 10) <= toDate);
  if (action) rows = rows.filter((r) => r.action === action);
  if (adminId) rows = rows.filter((r) => r.adminId === Number(adminId));
  rows.sort((a, b) => b.id - a.id);
  const capped = rows.slice(0, Number(limit) || 300);
  res.json({ rows: capped, total: rows.length });
});

// ---------- Employee punch history (session-level, for one employee) ----------
// Unlike /attendance (which groups into one row per employee-per-day), this returns
// every individual punch-in/punch-out session for a single employee, most recent first.
// Supports the same fromDate/toDate range as the other report endpoints.
router.get('/employees/:id/punch-history', (req, res) => {
  const data = load();
  const emp = data.employees.find((e) => e.id === Number(req.params.id));
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  const { fromDate, toDate, date, month } = req.query;

  let sessions = data.punches.filter((p) => p.employeeId === emp.id);
  if (date) sessions = sessions.filter((p) => p.date === date);
  if (month) sessions = sessions.filter((p) => p.date.startsWith(month));
  if (fromDate) sessions = sessions.filter((p) => p.date >= fromDate);
  if (toDate) sessions = sessions.filter((p) => p.date <= toDate);

  // Figure out, per date, which session was the FIRST one that day (status is decided
  // by the first punch-in of the day, same rule used everywhere else in the app).
  const firstIdByDate = {};
  data.punches
    .filter((p) => p.employeeId === emp.id)
    .forEach((p) => {
      if (firstIdByDate[p.date] == null || p.id < firstIdByDate[p.date]) firstIdByDate[p.date] = p.id;
    });

  sessions = [...sessions].sort((a, b) => (a.date === b.date ? b.id - a.id : b.date.localeCompare(a.date)));

  const rows = sessions.map((s) => ({
    id: s.id,
    date: s.date,
    punchInTime: s.punchInTime,
    punchOutTime: s.punchOutTime,
    durationWorked: formatDuration(totalMinutesWorked([s])),
    isFirstSessionOfDay: firstIdByDate[s.date] === s.id,
    status: firstIdByDate[s.date] === s.id ? computeStatus(s.punchInTime, office?.startTime, office?.graceMinutes) : null,
    punchInLat: s.punchInLat,
    punchInLng: s.punchInLng,
    punchOutLat: s.punchOutLat,
    punchOutLng: s.punchOutLng,
    deviceInfo: s.deviceInfo
  }));

  res.json({
    employee: { id: emp.id, employeeCode: emp.employeeCode, name: emp.name, department: emp.department },
    office: office ? { name: office.name } : null,
    rows
  });
});

// ---------- Attendance / reports ----------
// Groups an employee's punch records for one day into a single reportable row:
// first punch-in / last punch-out / all sessions / total hours worked.
function groupByEmployeeDay(punches, data) {
  const groups = {};
  punches.forEach((p) => {
    const key = p.employeeId + '|' + p.date;
    if (!groups[key]) groups[key] = [];
    groups[key].push(p);
  });

  return Object.values(groups).map((sessions) => {
    sessions.sort((a, b) => a.id - b.id);
    const first = sessions[0];
    const last = sessions[sessions.length - 1];
    const emp = data.employees.find((e) => e.id === first.employeeId);
    const office = emp ? data.offices.find((o) => o.id === emp.officeId) : null;
    const status = office
      ? computeStatus(first.punchInTime, office.startTime, office.graceMinutes)
      : first.punchInTime
      ? 'Present'
      : 'Absent';
    return {
      employeeId: first.employeeId,
      employeeCode: emp?.employeeCode || '',
      employeeName: emp?.name || '',
      department: emp?.department || '',
      officeName: office?.name || '',
      date: first.date,
      punchInTime: first.punchInTime,
      punchOutTime: last.punchOutTime,
      sessionCount: sessions.length,
      sessions: sessions.map((s) => ({ punchInTime: s.punchInTime, punchOutTime: s.punchOutTime })),
      totalWorked: formatDuration(totalMinutesWorked(sessions)),
      status
    };
  });
}

router.get('/attendance', (req, res) => {
  const { date, month, fromDate, toDate, employeeId, department } = req.query;
  const data = load();
  let punches = filterPunches(data.punches, { date, month, fromDate, toDate, employeeId });

  let rows = groupByEmployeeDay(punches, data);
  if (department) rows = rows.filter((r) => r.department.toLowerCase() === String(department).toLowerCase());

  // Also compute absentees for a specific date: active employees with no punch that day
  let absentees = [];
  if (date) {
    const punchedIds = new Set(punches.filter((p) => p.date === date).map((p) => p.employeeId));
    absentees = data.employees
      .filter((e) => e.active && !punchedIds.has(e.id) && (!department || e.department.toLowerCase() === String(department).toLowerCase()))
      .map((e) => ({
        employeeId: e.id,
        employeeCode: e.employeeCode,
        employeeName: e.name,
        department: e.department,
        date,
        status: 'Absent',
        punchInTime: null,
        punchOutTime: null
      }));
  }

  res.json({ rows, absentees, summary: summarize(rows, absentees) });
});

// ---------- Analytics (for charts) ----------
// Same filters as the other attendance endpoints. Returns:
//  - daily: [{date, present, late, absent}] for a trend chart
//  - totals: {present, late, absent} for an overall distribution chart
//  - byDepartment: [{department, present, late}] for a department comparison chart
// Note: "absent" per day is estimated as (currently-active matching employees) minus
// (present + late that day) — historical roster changes (joiners/leavers) aren't tracked
// day-by-day, so this is an approximation, same as the rest of the app.
// Adds n days to a 'YYYY-MM-DD' string and returns the result in the same format.
function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + n);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

router.get('/attendance/analytics', (req, res) => {
  const { date, month, fromDate, toDate, employeeId, department } = req.query;
  const data = load();
  const punches = filterPunches(data.punches, { date, month, fromDate, toDate, employeeId });
  let rows = groupByEmployeeDay(punches, data);
  if (department) rows = rows.filter((r) => r.department.toLowerCase() === String(department).toLowerCase());

  const matchingEmployees = data.employees.filter(
    (e) =>
      e.active &&
      (!department || (e.department || '').toLowerCase() === String(department).toLowerCase()) &&
      (!employeeId || e.id === Number(employeeId))
  );
  const totalActive = matchingEmployees.length;

  const byDateMap = {};
  // Zero-fill every date in the requested range so days with no punches at all
  // (e.g. a day nobody has clocked in yet) still show up as a 0/0/all-absent
  // point instead of being silently dropped from the trend, which shortened
  // or blanked out charts like the dashboard's "Last 7 Days Trend".
  if (fromDate && toDate) {
    for (let d = fromDate; d <= toDate; d = addDays(d, 1)) {
      byDateMap[d] = { date: d, present: 0, late: 0 };
    }
  }
  rows.forEach((r) => {
    if (!byDateMap[r.date]) byDateMap[r.date] = { date: r.date, present: 0, late: 0 };
    if (r.status === 'Present') byDateMap[r.date].present += 1;
    else if (r.status === 'Late') byDateMap[r.date].late += 1;
  });

  const daily = Object.values(byDateMap)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((d) => ({ ...d, absent: Math.max(0, totalActive - d.present - d.late) }));

  const totals = daily.reduce(
    (acc, d) => {
      acc.present += d.present;
      acc.late += d.late;
      acc.absent += d.absent;
      return acc;
    },
    { present: 0, late: 0, absent: 0 }
  );

  const byDeptMap = {};
  rows.forEach((r) => {
    const key = r.department || 'Unassigned';
    if (!byDeptMap[key]) byDeptMap[key] = { department: key, present: 0, late: 0 };
    if (r.status === 'Present') byDeptMap[key].present += 1;
    else if (r.status === 'Late') byDeptMap[key].late += 1;
  });
  const byDepartment = Object.values(byDeptMap).sort((a, b) => a.department.localeCompare(b.department));

  // Employee-wise attendance % ranking. "Working days" = distinct dates with any
  // activity in the filtered range (same approximation used for daily/absent
  // counts above, since there's no fixed office calendar tracked yet).
  // Note: this intentionally uses only dates that had at least one punch, NOT
  // the zero-filled `daily` array above — otherwise a range that includes days
  // nobody was ever expected to attend (e.g. weekends) would count as extra
  // "working days" and inflate everyone's absence count.
  const totalWorkingDays = new Set(rows.map((r) => r.date)).size;
  const byEmpMap = {};
  matchingEmployees.forEach((e) => {
    byEmpMap[e.id] = { employeeId: e.id, employeeCode: e.employeeCode, employeeName: e.name, department: e.department || '', present: 0, late: 0 };
  });
  rows.forEach((r) => {
    if (!byEmpMap[r.employeeId]) return; // not in matchingEmployees (e.g. deactivated) — skip
    if (r.status === 'Present') byEmpMap[r.employeeId].present += 1;
    else if (r.status === 'Late') byEmpMap[r.employeeId].late += 1;
  });
  const byEmployee = Object.values(byEmpMap)
    .map((e) => {
      const absent = Math.max(0, totalWorkingDays - e.present - e.late);
      const attendancePercent = totalWorkingDays > 0
        ? Math.round(((e.present + e.late) / totalWorkingDays) * 1000) / 10
        : 0;
      return { ...e, absent, attendancePercent };
    })
    .sort((a, b) => b.attendancePercent - a.attendancePercent || a.employeeName.localeCompare(b.employeeName));

  res.json({ daily, totals, byDepartment, byEmployee, totalWorkingDays, totalActiveEmployees: totalActive });
});

function summarize(rows, absentees) {
  const present = rows.filter((r) => r.status === 'Present').length;
  const late = rows.filter((r) => r.status === 'Late').length;
  const absent = absentees.length;
  return { present, late, absent, total: present + late + absent };
}

// Shared date/month/range/employee filtering used by the list, Excel export, and PDF export.
// fromDate/toDate ("YYYY-MM-DD") let the admin pick an arbitrary date-to-date range;
// they combine with (and narrow further than) the single-date/month filters if both are sent.
function filterPunches(punches, { date, month, fromDate, toDate, employeeId }) {
  let result = punches;
  if (date) result = result.filter((p) => p.date === date);
  if (month) result = result.filter((p) => p.date.startsWith(month));
  if (fromDate) result = result.filter((p) => p.date >= fromDate);
  if (toDate) result = result.filter((p) => p.date <= toDate);
  if (employeeId) result = result.filter((p) => p.employeeId === Number(employeeId));
  return result;
}

function describeFilters({ date, month, fromDate, toDate, department }) {
  let label;
  if (fromDate && toDate) label = `Date range: ${fromDate} to ${toDate}`;
  else if (fromDate) label = `From: ${fromDate}`;
  else if (toDate) label = `Up to: ${toDate}`;
  else if (date) label = `Date: ${date}`;
  else if (month) label = `Month: ${month}`;
  else label = 'All records';
  if (department) label += `  |  Department: ${department}`;
  return label;
}

// Works out the concrete list of 'YYYY-MM-DD' dates a report covers, so we know
// which days to check for absentees. Returns null when the range is unbounded
// (no date/month/range filter at all) since there's no sensible day-by-day
// absentee list to build in that case.
function getReportDates({ date, month, fromDate, toDate }) {
  const today = todayDateStr();
  if (fromDate && toDate) {
    const dates = [];
    for (let d = fromDate; d <= toDate; d = addDays(d, 1)) dates.push(d);
    return dates;
  }
  if (date) return [date];
  if (month) {
    const [y, m] = month.split('-').map(Number);
    const lastDay = new Date(y, m, 0).getDate(); // day 0 of next month = last day of this month
    const lastDateStr = `${month}-${String(lastDay).padStart(2, '0')}`;
    const cappedLast = lastDateStr > today ? today : lastDateStr;
    const firstDateStr = `${month}-01`;
    if (firstDateStr > cappedLast) return [];
    const dates = [];
    for (let d = firstDateStr; d <= cappedLast; d = addDays(d, 1)) dates.push(d);
    return dates;
  }
  return null;
}

// Builds one "Absent" row per active employee per date they had no punch,
// shaped like the groupByEmployeeDay rows so it can be merged straight into
// the same report table/sheet.
function buildAbsenteeRows(reportDates, data, { employeeId, department }) {
  if (!reportDates) return [];
  const punchedByDate = {};
  data.punches.forEach((p) => {
    if (!punchedByDate[p.date]) punchedByDate[p.date] = new Set();
    punchedByDate[p.date].add(p.employeeId);
  });

  const employees = data.employees.filter(
    (e) =>
      e.active &&
      (!employeeId || e.id === Number(employeeId)) &&
      (!department || (e.department || '').toLowerCase() === String(department).toLowerCase())
  );

  const rows = [];
  reportDates.forEach((d) => {
    const punchedIds = punchedByDate[d] || new Set();
    employees.forEach((e) => {
      if (punchedIds.has(e.id)) return;
      const office = data.offices.find((o) => o.id === e.officeId);
      rows.push({
        employeeId: e.id,
        employeeCode: e.employeeCode,
        employeeName: e.name,
        department: e.department || '',
        officeName: office?.name || '',
        date: d,
        punchInTime: null,
        punchOutTime: null,
        sessionCount: 0,
        totalWorked: '0h 0m',
        status: 'Absent'
      });
    });
  });
  return rows;
}

// Sort used across reports: Employee ID first (as requested), then date, so
// each employee's days appear grouped together in ID order.
function sortReportRows(rows) {
  rows.sort((a, b) => a.employeeId - b.employeeId || a.date.localeCompare(b.date));
  return rows;
}

router.get('/attendance/export', async (req, res) => {
  const { date, month, fromDate, toDate, employeeId, department } = req.query;
  const data = load();
  let punches = filterPunches(data.punches, { date, month, fromDate, toDate, employeeId });
  let rows = groupByEmployeeDay(punches, data);
  if (department) rows = rows.filter((r) => r.department.toLowerCase() === String(department).toLowerCase());
  const absenteeRows = buildAbsenteeRows(getReportDates({ date, month, fromDate, toDate }), data, { employeeId, department });
  rows = sortReportRows([...rows, ...absenteeRows]);

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Attendance');
  sheet.columns = [
    { header: 'Employee ID', key: 'employeeId', width: 12 },
    { header: 'Employee Code', key: 'employeeCode', width: 15 },
    { header: 'Name', key: 'employeeName', width: 22 },
    { header: 'Department', key: 'department', width: 16 },
    { header: 'Date', key: 'date', width: 14 },
    { header: 'First Punch In', key: 'punchInTime', width: 14 },
    { header: 'Last Punch Out', key: 'punchOutTime', width: 14 },
    { header: 'Sessions', key: 'sessionCount', width: 10 },
    { header: 'Total Hours Worked', key: 'totalWorked', width: 16 },
    { header: 'Status', key: 'status', width: 10 },
    { header: 'Office', key: 'officeName', width: 16 }
  ];
  rows.forEach((r) => sheet.addRow(r));
  sheet.getRow(1).font = { bold: true };

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="attendance_report.xlsx"');
  await workbook.xlsx.write(res);
  res.end();
});

// ---------- PDF export ----------
// Same filters as /attendance and /attendance/export (date, month, fromDate/toDate range,
// employeeId, department), rendered as a printable landscape PDF table.
router.get('/attendance/export-pdf', (req, res) => {
  const { date, month, fromDate, toDate, employeeId, department } = req.query;
  const data = load();
  let punches = filterPunches(data.punches, { date, month, fromDate, toDate, employeeId });
  let rows = groupByEmployeeDay(punches, data);
  if (department) rows = rows.filter((r) => r.department.toLowerCase() === String(department).toLowerCase());
  const absenteeRows = buildAbsenteeRows(getReportDates({ date, month, fromDate, toDate }), data, { employeeId, department });
  rows = sortReportRows([...rows, ...absenteeRows]);

  const doc = new PDFDocument({ margin: 30, size: 'A4', layout: 'landscape' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="attendance_report.pdf"');
  doc.pipe(res);

  const headers = ['ID', 'Employee', 'Dept', 'Date', 'First In', 'Last Out', 'Sessions', 'Total Hours', 'Status', 'Office'];
  const colWidths = [35, 125, 80, 65, 55, 55, 50, 65, 55, 90];
  const startX = doc.page.margins.left;
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 18;

  function drawHeaderRow(y) {
    doc.rect(startX, y - 3, tableWidth, rowHeight).fill('#2d3748');
    let x = startX;
    doc.fontSize(9).fillColor('#ffffff').font('Helvetica-Bold');
    headers.forEach((h, i) => {
      doc.text(h, x + 4, y, { width: colWidths[i] - 6, ellipsis: true });
      x += colWidths[i];
    });
    doc.font('Helvetica').fillColor('#000000');
  }

  function drawDataRow(cells, y, striped) {
    if (striped) doc.rect(startX, y - 3, tableWidth, rowHeight).fill('#f4f5f7').fillColor('#000000');
    let x = startX;
    doc.fontSize(8.5).fillColor('#1a1a1a');
    cells.forEach((c, i) => {
      doc.text(String(c), x + 4, y, { width: colWidths[i] - 6, ellipsis: true });
      x += colWidths[i];
    });
  }

  doc.fontSize(16).font('Helvetica-Bold').text('Attendance Report', { align: 'center' });
  doc.font('Helvetica').fontSize(10).fillColor('#555555')
    .text(describeFilters({ date, month, fromDate, toDate, department }), { align: 'center' });
  doc.fillColor('#000000');
  doc.moveDown(1);

  let y = doc.y;
  drawHeaderRow(y);
  y += rowHeight;

  const pageBottom = doc.page.height - doc.page.margins.bottom;
  rows.forEach((r, idx) => {
    if (y + rowHeight > pageBottom) {
      doc.addPage();
      y = doc.page.margins.top;
      drawHeaderRow(y);
      y += rowHeight;
    }
    drawDataRow(
      [
        r.employeeId,
        `${r.employeeName} (${r.employeeCode})`,
        r.department || '-',
        r.date,
        r.punchInTime || '--:--',
        r.punchOutTime || (r.status === 'Absent' ? '--:--' : 'still in'),
        r.sessionCount,
        r.totalWorked,
        r.status,
        r.officeName || '-'
      ],
      y,
      idx % 2 === 1
    );
    y += rowHeight;
  });

  if (!rows.length) {
    doc.fontSize(10).fillColor('#777777').text('No punch records match this filter.', startX, y + 4);
    y += rowHeight;
  }

  if (y + 30 > pageBottom) {
    doc.addPage();
    y = doc.page.margins.top;
  }
  const summary = {
    present: rows.filter((r) => r.status === 'Present').length,
    late: rows.filter((r) => r.status === 'Late').length,
    absent: rows.filter((r) => r.status === 'Absent').length
  };
  doc.moveDown();
  doc.fontSize(10).fillColor('#000000').font('Helvetica-Bold')
    .text(`Present: ${summary.present}    Late: ${summary.late}    Absent: ${summary.absent}    Total records: ${rows.length}`, startX, y + 14);

  doc.end();
});

module.exports = router;
