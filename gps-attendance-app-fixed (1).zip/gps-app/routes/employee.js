const express = require('express');
const bcrypt = require('bcryptjs');
const PDFDocument = require('pdfkit');
const { load, save, nextId } = require('../db/store');
const { signToken, distanceMeters, todayDateStr, timeStr, computeStatus, formatDuration, totalMinutesWorked } = require('../utils');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ---------- Employee auth ----------
router.post('/login', (req, res) => {
  const { idOrMobile, password, deviceId } = req.body;
  if (!idOrMobile || !password) return res.status(400).json({ error: 'idOrMobile and password required' });
  const data = load();
  const emp = data.employees.find((e) => e.employeeCode === idOrMobile || e.mobile === idOrMobile);
  if (!emp || !emp.active) return res.status(401).json({ error: 'Invalid credentials' });
  if (!bcrypt.compareSync(password, emp.passwordHash)) return res.status(401).json({ error: 'Invalid credentials' });

  // Basic single-device control (section 7): lock account to first device that logs in.
  // Admin can clear this via "unlock device".
  if (emp.activeDeviceId && deviceId && emp.activeDeviceId !== deviceId) {
    return res.status(403).json({ error: 'This account is already active on another device. Ask your admin to unlock it.' });
  }
  if (deviceId && !emp.activeDeviceId) {
    emp.activeDeviceId = deviceId;
    save(data);
  }

  const token = signToken({ role: 'employee', id: emp.id, employeeCode: emp.employeeCode });
  res.json({ token, employee: { id: emp.id, employeeCode: emp.employeeCode, name: emp.name } });
});

router.use(requireAuth('employee'));

function getEmployee(data, req) {
  return data.employees.find((e) => e.id === req.user.id);
}

// ---------- Dashboard ----------
router.get('/me', (req, res) => {
  const data = load();
  const emp = getEmployee(data, req);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  const today = todayDateStr();
  const todaySessions = data.punches
    .filter((p) => p.employeeId === emp.id && p.date === today)
    .sort((a, b) => a.id - b.id);

  const firstSession = todaySessions[0] || null;
  const openSession = todaySessions.find((s) => s.punchInTime && !s.punchOutTime) || null;
  // Late/Present is decided by the FIRST punch-in of the day, not later sessions
  const status = firstSession ? computeStatus(firstSession.punchInTime, office?.startTime, office?.graceMinutes) : 'Not punched in';
  const totalMinutes = totalMinutesWorked(todaySessions);

  res.json({
    name: emp.name,
    employeeCode: emp.employeeCode,
    department: emp.department,
    date: today,
    time: timeStr(),
    todayStatus: status,
    hasOpenSession: !!openSession,
    totalToday: formatDuration(totalMinutes),
    sessions: todaySessions.map((s) => ({ punchInTime: s.punchInTime, punchOutTime: s.punchOutTime })),
    office: office ? { name: office.name, radiusMeters: office.radiusMeters } : null
  });
});

// ---------- Punch In ----------
router.post('/punch-in', (req, res) => {
  const { latitude, longitude, accuracy, deviceInfo, mockLocation } = req.body;
  if (latitude == null || longitude == null) return res.status(400).json({ error: 'latitude and longitude are required' });

  // Basic mock-location guard (section 7). Real detection needs native Android APIs
  // (Location.isFromMockProvider()); the app should send that flag here.
  if (mockLocation === true) {
    return res.status(403).json({ error: 'Mock/fake GPS location detected. Punch rejected.' });
  }

  const data = load();
  const emp = getEmployee(data, req);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  if (!office) return res.status(400).json({ error: 'No office assigned to this employee' });

  const today = todayDateStr();
  const todaySessions = data.punches.filter((p) => p.employeeId === emp.id && p.date === today);
  const openSession = todaySessions.find((s) => s.punchInTime && !s.punchOutTime);
  if (openSession) {
    return res.status(409).json({ error: 'You already have an open session — punch out before punching in again.' });
  }

  const dist = distanceMeters(Number(latitude), Number(longitude), office.latitude, office.longitude);
  if (dist > office.radiusMeters) {
    return res.status(403).json({
      error: `You are ${Math.round(dist)}m from ${office.name}, outside the allowed ${office.radiusMeters}m radius.`
    });
  }

  // Each punch-in starts a NEW session record — an employee can come and go
  // multiple times a day (e.g. morning shift + evening shift); all sessions
  // for the day are summed into total hours worked.
  const now = new Date();
  const punchRecord = {
    id: nextId(data, 'punches'),
    employeeId: emp.id,
    date: today,
    punchInTime: timeStr(now),
    punchOutTime: null,
    punchInLat: Number(latitude),
    punchInLng: Number(longitude),
    punchInAccuracy: accuracy != null ? Number(accuracy) : null,
    punchOutLat: null,
    punchOutLng: null,
    punchOutAccuracy: null,
    deviceInfo: deviceInfo || null,
    serverTimestampIn: now.toISOString(),
    serverTimestampOut: null
  };
  data.punches.push(punchRecord);
  save(data);

  const firstToday = [...todaySessions, punchRecord].sort((a, b) => a.id - b.id)[0];
  res.json({
    ok: true,
    punchInTime: punchRecord.punchInTime,
    status: computeStatus(firstToday.punchInTime, office.startTime, office.graceMinutes)
  });
});

// ---------- Punch Out ----------
router.post('/punch-out', (req, res) => {
  const { latitude, longitude, accuracy, deviceInfo, mockLocation } = req.body;
  if (latitude == null || longitude == null) return res.status(400).json({ error: 'latitude and longitude are required' });

  if (mockLocation === true) {
    return res.status(403).json({ error: 'Mock/fake GPS location detected. Punch rejected.' });
  }

  const data = load();
  const emp = getEmployee(data, req);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  if (!office) return res.status(400).json({ error: 'No office assigned to this employee' });

  const today = todayDateStr();
  const punchRecord = data.punches.find((p) => p.employeeId === emp.id && p.date === today && p.punchInTime && !p.punchOutTime);
  if (!punchRecord) {
    return res.status(409).json({ error: 'You must Punch In before you can Punch Out' });
  }

  const dist = distanceMeters(Number(latitude), Number(longitude), office.latitude, office.longitude);
  if (dist > office.radiusMeters) {
    return res.status(403).json({
      error: `You are ${Math.round(dist)}m from ${office.name}, outside the allowed ${office.radiusMeters}m radius.`
    });
  }

  const now = new Date();
  punchRecord.punchOutTime = timeStr(now);
  punchRecord.punchOutLat = Number(latitude);
  punchRecord.punchOutLng = Number(longitude);
  punchRecord.punchOutAccuracy = accuracy != null ? Number(accuracy) : null;
  punchRecord.deviceInfo = deviceInfo || punchRecord.deviceInfo;
  punchRecord.serverTimestampOut = now.toISOString();
  save(data);

  res.json({ ok: true, punchOutTime: punchRecord.punchOutTime });
});

// ---------- History ----------
// Optional fromDate/toDate ("YYYY-MM-DD") let the employee narrow their own history
// to a date range, same convention used on the admin side.
function getOwnHistoryRows(data, emp, office, { fromDate, toDate } = {}) {
  const byDate = {};
  data.punches
    .filter((p) => p.employeeId === emp.id)
    .filter((p) => (!fromDate || p.date >= fromDate) && (!toDate || p.date <= toDate))
    .forEach((p) => {
      if (!byDate[p.date]) byDate[p.date] = [];
      byDate[p.date].push(p);
    });

  return Object.keys(byDate)
    .sort((a, b) => (a < b ? 1 : -1))
    .map((date) => {
      const sessions = byDate[date].sort((a, b) => a.id - b.id);
      const first = sessions[0];
      const last = sessions[sessions.length - 1];
      return {
        date,
        sessions: sessions.map((s) => ({ punchInTime: s.punchInTime, punchOutTime: s.punchOutTime })),
        punchInTime: first.punchInTime,
        punchOutTime: last.punchOutTime,
        totalWorked: formatDuration(totalMinutesWorked(sessions)),
        status: computeStatus(first.punchInTime, office?.startTime, office?.graceMinutes)
      };
    });
}

router.get('/history', (req, res) => {
  const data = load();
  const emp = getEmployee(data, req);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  const { fromDate, toDate } = req.query;
  res.json(getOwnHistoryRows(data, emp, office, { fromDate, toDate }));
});

// ---------- Self-service PDF export ----------
// Employees can only ever export their OWN history — employeeId always comes from
// the authenticated token (getEmployee), never from the request.
router.get('/history/export-pdf', (req, res) => {
  const data = load();
  const emp = getEmployee(data, req);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  const office = data.offices.find((o) => o.id === emp.officeId);
  const { fromDate, toDate } = req.query;
  const rows = getOwnHistoryRows(data, emp, office, { fromDate, toDate }).sort((a, b) => a.date.localeCompare(b.date));

  const doc = new PDFDocument({ margin: 30, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="my_attendance_history.pdf"');
  doc.pipe(res);

  doc.fontSize(16).font('Helvetica-Bold').text('My Attendance History', { align: 'center' });
  doc.font('Helvetica').fontSize(10).fillColor('#555555').text(`${emp.name} (${emp.employeeCode})`, { align: 'center' });
  let subtitle = 'All records';
  if (fromDate && toDate) subtitle = `Date range: ${fromDate} to ${toDate}`;
  else if (fromDate) subtitle = `From: ${fromDate}`;
  else if (toDate) subtitle = `Up to: ${toDate}`;
  doc.text(subtitle, { align: 'center' });
  doc.fillColor('#000000');
  doc.moveDown(1);

  const headers = ['Date', 'First In', 'Last Out', 'Sessions', 'Total Hours', 'Status'];
  const colWidths = [80, 80, 80, 60, 90, 80];
  const startX = doc.page.margins.left;
  const tableWidth = colWidths.reduce((a, b) => a + b, 0);
  const rowHeight = 18;

  function drawHeaderRow(y) {
    doc.rect(startX, y - 3, tableWidth, rowHeight).fill('#2d3748');
    let x = startX;
    doc.fontSize(9).fillColor('#ffffff').font('Helvetica-Bold');
    headers.forEach((h, i) => {
      doc.text(h, x + 4, y, { width: colWidths[i] - 6, ellipsis: true });
      x += colWidths[i];
    });
    doc.font('Helvetica').fillColor('#000000');
  }

  function drawDataRow(cells, y, striped) {
    if (striped) doc.rect(startX, y - 3, tableWidth, rowHeight).fill('#f4f5f7').fillColor('#000000');
    let x = startX;
    doc.fontSize(8.5).fillColor('#1a1a1a');
    cells.forEach((c, i) => {
      doc.text(String(c), x + 4, y, { width: colWidths[i] - 6, ellipsis: true });
      x += colWidths[i];
    });
  }

  let y = doc.y;
  drawHeaderRow(y);
  y += rowHeight;

  const pageBottom = doc.page.height - doc.page.margins.bottom;
  rows.forEach((r, idx) => {
    if (y + rowHeight > pageBottom) {
      doc.addPage();
      y = doc.page.margins.top;
      drawHeaderRow(y);
      y += rowHeight;
    }
    drawDataRow(
      [r.date, r.punchInTime || '--:--', r.punchOutTime || 'still in', r.sessions.length, r.totalWorked, r.status],
      y,
      idx % 2 === 1
    );
    y += rowHeight;
  });

  if (!rows.length) {
    doc.fontSize(10).fillColor('#777777').text('No punch records for this range.', startX, y + 4);
  }

  doc.end();
});

module.exports = router;
