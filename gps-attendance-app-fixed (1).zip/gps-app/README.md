# GPS Attendance System — Web Prototype

This is a working prototype of the attendance system described in the brief:
employees punch in/out only when inside an office's GPS radius, and an admin
panel manages employees, offices, and reports.

**Important scope note:** this environment can't compile a signed native
Android APK (no Android SDK/Gradle here). So instead of a native app, the
employee side is a **mobile web app** — it runs in any Android phone's
browser, uses the browser's GPS (`navigator.geolocation`), and works the
same way a real app would for punching in/out. Everything else (backend
logic, database, admin panel, radius rule, reports, Excel export) is fully
functional. See "Path to a real native APK" below for what a developer would
change to ship an actual signed app.

## What's implemented (maps to the brief's sections)

- Employee login (ID or mobile + password), session token, logout — §3
- Dashboard: name, date/time, today's status, punch in/out times and buttons — §3
- GPS punch in/out with haversine distance check against admin-set office
  radius; rejected outside radius — §3
- Punch record stores employee id/name, date, in/out time, lat/lng, GPS
  accuracy, device info, server timestamp — §3
- Attendance history with Present/Late/Absent — §3
- Admin login, employee CRUD (create/edit/deactivate/reset password), one or
  more office locations with radius + start time + grace period — §4
- Attendance views (daily/monthly/by employee/by department), absentee list,
  Present/Late/Absent counts, Excel export — §4
- Rules: punch-out requires punch-in first, times are stamped by the
  **server clock** (not the phone's clock), an employee can't punch in again
  while already punched in — §5
- **Multiple sessions per day**: an employee can punch in/out more than once
  in the same day (e.g. morning shift, leave, come back for an evening
  shift). Every session is recorded, and total hours worked for the day is
  the sum across all sessions. Late/Present/Absent status is decided by the
  **first** punch-in of the day. The admin report and Excel export show the
  first punch-in, last punch-out, number of sessions, and total hours worked
  per employee per day.
- Late/Absent logic driven by office start time + configurable grace minutes — §6
- Passwords hashed (bcrypt), JWT-based API auth, employees can only see their
  own attendance, only admins can edit employee data, basic single-device
  lock per employee account, and a placeholder for mock-GPS rejection — §7

## What's a placeholder, and why

- **Fake/mock GPS detection**: real detection needs a native Android API call
  (`Location.isFromMockProvider()`), which a browser cannot access. The
  backend already has a `mockLocation` flag wired into `/punch-in` and
  `/punch-out` — a native app just needs to set it correctly.
- **Database**: uses a JSON file (`db/data.json`) instead of MySQL/Postgres,
  so the prototype runs anywhere without setting up a database server. The
  data access is isolated in `db/store.js` — swapping it for a real SQL
  database is a contained change, not a rewrite.

## Running it

```bash
npm install
npm run seed     # creates the first admin login + a demo office
npm start        # starts the server on http://localhost:3000
```

Then open:
- `http://localhost:3000/admin.html` — Admin Panel
- `http://localhost:3000/employee.html` — Employee punch page (open this on
  a phone browser to test real GPS; on a laptop your browser will ask for
  location permission and use your computer's approximate location)

Seed prints something like:
```
Created admin login -> username: admin / password: Admin@123
```
**Change this password immediately** — there's no forced-reset flow in this
prototype yet.

First steps in the admin panel:
1. Go to **Office Locations** and add/edit your real office's latitude,
   longitude, allowed radius, start time, and grace minutes. (Tip: right-click
   your office on Google Maps to copy exact coordinates.)
2. Go to **Employees** and add employees one at a time, or use **Bulk Import
   Employees (CSV)** to add many at once (download the template, fill it in,
   upload it back).
3. Give each employee their ID/mobile + temporary password to log in at
   `/employee.html`.

## Admin roles & permissions

The seeded `admin` account is a **Super Admin** with full access. From the
**Admins** tab (visible only to Super Admins), you can create additional
admin logins with one of two roles:

- **Super Admin** — full access: manage employees (add/edit/deactivate/reset
  password/bulk import), manage office locations, manage other admin
  accounts, and view everything.
- **Manager** — read-only access: can view the dashboard, attendance
  reports, analytics, employee roster, office list, and the audit log, but
  cannot add/edit/deactivate employees or offices, reset passwords, run a
  bulk import, or manage admin accounts. Buttons for those actions are
  disabled in the UI and the API rejects the requests server-side too.

At least one active Super Admin must always remain — the API blocks
deactivating the last one or removing your own Super Admin role.

## Audit log

Every admin-side change (login, add/edit/deactivate employee, password
resets, office changes, bulk imports, admin account changes) is recorded
with a timestamp, the admin who did it, and a short description. View and
filter it from the **Audit Log** tab (by date range or action type) — it's
visible to both Super Admins and Managers for transparency.

## Path to a real native APK

To turn this into the installable Android app the brief asks for, a
developer would:
1. Build a small native Android (Kotlin) or Flutter app with two screens
   (login, dashboard) that call the same `/api/employee/...` endpoints here.
2. Use `FusedLocationProviderClient` (Android) for GPS, and check
   `location.isFromMockProvider()` before sending `mockLocation: true/false`.
3. Sign the APK with a release keystore and distribute the `.apk` file
   directly (no Play Store needed, matching §8 of the brief).
4. Point the app's API base URL at wherever this backend is deployed (a VPS
   or cloud server, per §12), and swap `db/store.js` for a real MySQL/Postgres
   connection for production use with 50+ concurrent users.

## Project structure

```
attendance-app/
├── server.js              # Express app entry point
├── seed.js                 # creates first admin + demo office
├── utils.js                 # distance calc, JWT helpers, status logic
├── middleware/auth.js        # JWT auth guard
├── routes/admin.js           # admin API (employees, offices, reports)
├── routes/employee.js        # employee API (login, punch in/out, history)
├── db/store.js               # JSON-file data layer (swap for real DB later)
├── db/data.json               # the actual data (created on first run)
└── public/
    ├── index.html            # landing page
    ├── admin.html             # admin panel UI
    ├── employee.html          # employee punch UI
    └── style.css              # shared styling
```
