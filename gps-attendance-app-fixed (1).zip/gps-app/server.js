const express = require('express');
const cors = require('cors');
const path = require('path');

const adminRoutes = require('./routes/admin');
const employeeRoutes = require('./routes/employee');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/admin', adminRoutes);
app.use('/api/employee', employeeRoutes);

app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`GPS Attendance server running on http://localhost:${PORT}`);
  console.log(`  Admin panel:    http://localhost:${PORT}/admin.html`);
  console.log(`  Employee punch: http://localhost:${PORT}/employee.html`);
});
